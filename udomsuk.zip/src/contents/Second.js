import React from 'react'
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import Motor from '../components/Card2ndhand';


function Second() {
    return (

        <>
            <Navbar />
            <div className="bg-white-100 h-screen flex justify-center text-2xl">
                <div className="flex-row text-center justify-center m-6">
                    <span className="animate-pulse text-3xl">รถมือสอง</span>
                    <>
                    <Motor/>
                    </>
                </div>
            </div>
            <Footer />
        </>

    )
}

export default Second;
