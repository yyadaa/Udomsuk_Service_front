import React from 'react';
import Figure from 'react-bootstrap/Figure'
import Image1 from '../img/ensure/khumpai.png'
import Image2 from '../img/ensure/acane.png'
import Image3 from '../img/ensure/asia.png'
import Image4 from '../img/ensure/muangthai.png'
import Image5 from '../img/ensure/navakij.png'
import Image6 from '../img/ensure/diphaya.png'
import Image7 from '../img/ensure/thai.png'
import Image8 from '../img/ensure/axa.png'
import Image9 from '../img/ensure/misui.jpeg'
import Image10 from '../img/ensure/mittare.jpeg'
function Ensure() {
    return (
        <Figure>
            <Figure.Caption className="text-4xl flex justify-center p-5 rounded-md bg-bluebg m-10 text-white item-center ">
                ประกันในเครือ
            </Figure.Caption>
            <div className="flex justify-center flex-row space-x-6 my-10 ">
                <Figure.Image
                    rounded={20}
                    width={200}
                    height={200}
                    alt="khumpai"
                    src={Image1}
                />
                <Figure.Image
                    rounded={20}
                    width={200}
                    height={200}
                    alt="acane"
                    src={Image2}
                />
                <Figure.Image
                    rounded={20}
                    width={200}
                    height={200}
                    alt="asia"
                    src={Image3}
                />
                <Figure.Image
                    rounded={20}
                    width={200}
                    height={200}
                    alt="171x180"
                    src={Image4}
                />
                <Figure.Image
                    rounded={20}
                    width={200}
                    height={200}
                    alt="171x180"
                    src={Image5}
                />
            </div>
            <div className="flex justify-center flex-row space-x-6 my-10 ">
                <Figure.Image
                    rounded={20}
                    width={200}
                    height={200}
                    alt="171x180"
                    src={Image6}
                />
                <Figure.Image
                    rounded={20}
                    width={200}
                    height={200}
                    alt="171x180"
                    src={Image7}
                />
                <Figure.Image
                    rounded={20}
                    width={200}
                    height={200}
                    alt="171x180"
                    src={Image8}
                />
                <Figure.Image
                    rounded={20}
                    width={200}
                    height={200}
                    alt="171x180"
                    src={Image9}
                />
                <Figure.Image
                    rounded={20}
                    width={200}
                    height={200}
                    alt="171x180"
                    src={Image10}
                />
            </div>


        </Figure>
    )
}

export default Ensure