import React from 'react'
import Image from '../img/Hondaclick110/click1.jpg'
import Image1 from '../img/HondaSonic/Sonic1.jpg'

function Motor() {
    return (
        <>
            <div className="space-x-6 flex h-full">
                <div className=" bg-bluebg bg-opacity-25 h-full rounded-md p-4 flex justify-center items-center flex-col">
                    <img src={Image} height="500" width="200"></img>
                    <span className=" text-2xl m-6">Honda Click 110 i</span>
                </div>
                <div className=" bg-bluebg bg-opacity-25 h-full rounded-md p-4 flex justify-center items-center flex-col">
                    <img src={Image1} height="500" width="200"></img>
                    <span className=" text-2xl m-3">Honda Sonic </span>
                </div>
                <div className=" bg-bluebg bg-opacity-25 h-full rounded-md p-4 flex justify-center items-center flex-col">
                    <img src={Image} height="500" width="200"></img>
                    <span className=" text-2xl">Honda Click 110 i</span>
                </div>

            </div>
        </>
    )
}

export default Motor